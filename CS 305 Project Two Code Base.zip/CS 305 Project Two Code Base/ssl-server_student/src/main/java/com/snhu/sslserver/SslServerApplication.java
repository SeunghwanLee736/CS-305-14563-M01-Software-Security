package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class SslServerApplication {

    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }

    /**
     * Endpoint required by the project:
     * https://localhost:8443/hash
     *
     * Returns a unique data string (includes your name) and its SHA-256 checksum.
     */
    @GetMapping("/hash")
    public String getHash() {
        // TODO: Replace with YOUR name for the screenshot evidence
        String name = "Seunghwan";

        // Unique data string (name + random + timestamp)
        String data = name + " | CS-305 Project Two | " + System.currentTimeMillis() + " | nonce=" + randomHex(16);

        String checksum = sha256Hex(data);

        // Simple plaintext output is fine (easy screenshot)
        return "name: " + name + "\n"
             + "data: " + data + "\n"
             + "sha256: " + checksum + "\n";
    }

    private static String sha256Hex(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(input.getBytes(StandardCharsets.UTF_8));
            return toHex(digest);
        } catch (NoSuchAlgorithmException e) {
            // If SHA-256 isn't available, that's a fatal server misconfiguration
            throw new IllegalStateException("SHA-256 algorithm not available", e);
        }
    }

    private static String randomHex(int numBytes) {
        byte[] b = new byte[numBytes];
        SECURE_RANDOM.nextBytes(b);
        return toHex(b);
    }

    private static String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte by : bytes) {
            sb.append(String.format("%02x", by));
        }
        return sb.toString();
    }
}
